
We provide this copy of The CImg Library core under its CeCILL-C 
license. For more information, please visit http://cimg.eu/

